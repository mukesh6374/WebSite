<nav id="navb" class="navbar navbar-inverse navbar-fixed-top col-lg-12 col-md-12 col-sm-12 col-xs-12" role="navigation">
                      <div class="container-fluid">
                           <div class="navbar-header">
                    <button id="bt" type="button" class="navbar-toggle collapsed" aria-controls="navbar" aria-expanded="false" data-toggle="collapse" onclick="#menu">
                        <span class="sr-only">navigaton</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" style="width:196px; font-size:18px;" href="login.php" ><strong>Softwarez Solution</strong></a>

                 </div>

                 <div id="menu" class="collapse navbar-collapse" >
                     <ul class="nav navbar-nav">
                      <li class="active"><a href="login.php"><strong>Home</strong></a></li>
                      <li id="time"><?php date_default_timezone_set('Asia/Kolkata'); ?> &nbsp;&nbsp;&nbsp;&nbsp;<strong><?php echo "Time: ".date("h.i.sa")?>&nbsp;&nbsp;&nbsp;&nbsp; </strong></li>
                      
                      </ul>
                     <ul class="nav nav-pills navbar-nav navbar-right ">
                        <?php 
                              $var=0;
                              $var=$_SESSION['login'];
                              if($var)
                              {
                            ?>
                            <li id="time" style="margin-right:10px;"><strong><?php echo "Date: ".date("d.M.Y"); ?></strong></li>

                            <a id="drop" class="dropdown-toggle" data-toggle="dropdown" href="#">
                                       <span style="padding-top:10px;"class="glyphicon glyphicon-user"></span>&nbsp;<?php echo $_SESSION['user'] ?>
                            </a>
                            <ul  id="submenu" class="dropdown-menu" >
                                 <img src="images/user.jpg" class="img-responsive img-circle"  style="height:100px; width:100px; margin-left:20px;" />
                                  <a href="#" class="btn btn-info" style="margin-left:20px;"><strong>Edit Profile</strong></a>
                            </ul>
                          
                             <a id="navgly" class="btn  glyphicon glyphicon-log-out" role="button" href="logout.php"><strong >&nbsp;Log-out</strong></a>
                           <?php 
                           }
                           else
                           {
                            ?>
                            <li id="time" style="margin-right:10px;"><strong><?php echo "Date: ".date("d.M.Y"); ?></strong></li>
                            <a id="navgly2" class="btn  glyphicon glyphicon-user" role="button" href="#modal" data-toggle="modal" ><strong >&nbsp;Register</strong></a>
                            <a id="navgly2" class="btn  glyphicon glyphicon-log-in" role="button" href="#Modal" data-toggle="modal" ><strong >&nbsp;Log-in</strong></a>
                        <?php
                           }
                           ?>

                     </ul>
                 </div>
              </div>
            
</nav>

