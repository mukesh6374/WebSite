<div id="footer" class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
   <div class="col-lg-3 col-md-4 col-sm-5 col-xs-12">
   	    <ul style="color:rgb(176, 216, 207);">
   	       <ul><a href="#"><h3 style="color:white;">SoftwareZ Solution</h3></a></ul>
   	       <ul><a href="">Web Developemnt</a></ul>
   	       <ul><a href="#">Virtual Assistance</a></ul>
   	       <ul><a href="#">Mobile App Developemnt</a></ul>
   	       <ul><a href="#">Software Developement</a></ul>
   	       <ul><a href="#">About Us</a></ul>	    
   	    </ul>
   </div>
   <div class="col-lg-3 col-md-4 col-sm-5 col-xs-12">
   <ul style="color:rgb(176, 216, 207);">
	    <ul><a href="#"></a><h3 style="color:white;">Contact Us</h3></ul>
	    <ul>Softwarez solution Office<br>
        81 KK Nagar Sikendra Agra ,<br>
        India- 282007<br>
        Phone: +91-8449770871<br>
        mail:support.app@naipathya.in
       </ul>
   </ul>
   </div>
   <div class="col-lg-3 col-md-4 col-sm-5 col-xs-12">
    <ul>
        <ul><h3 style="color:white;">SHARE OUR PAGE</h3></ul>
	    
	    <ul><div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><a href="#"><img src="images/google+.png" class="img-responsive " style="width:50px; height:40px; "></a></div>
	    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><a href="#"><img src="images/fb.png" class="img-responsive" style="width:50px; height:40px; "></a></div>
	    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><a href="#"><img src="images/linkedin.png" class="img-responsive" style="width:50px; height:40px; "></a></div>
	    </ul>
   </ul>
   </div>
   <div class="col-lg-3 col-md-4 col-sm-5 col-xs-12">
   <ul style="color:rgb(176, 216, 207);">
	    <ul><h3 style="color:white;">FOLLOW US</h3></ul>
	    <ul>
	    <a href="#"><img src="images/facebook.png" style="width:50px; height:50px; " class="img-responsive"></a>
       </ul>
   </ul>
   </div>
</div>
<div id="footerid" class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <p align="center" > Terms & Conditions&nbsp;&nbsp;Privacy Policy &nbsp;&nbsp; Refund Policy<br>
           Copyright &copy; <?php echo date('Y');?> Softwarez Solution | All Rights Reserved

         </p>

   	
   </div>