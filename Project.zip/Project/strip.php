 <div id="stripid" >
 <div id="web" class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
      <div id="imgid1" class="col-lg-4 col-md-5 col-sm-4 col-xs-4">
      	   <img  src="images/web.png" class="img-responsive" >
      </div>
      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
      	   <h4>
  	  		&nbsp;&nbsp;&nbsp;&nbsp;Web <br>Desigining<br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;& <br>Development<br>
  	  	   </h4> 	  
      </div>
      <div class="col-lg-11 col-md-11 col-sm-11 col-xs-11">
      	   <p>We can help you design your company's / organization's website from scratch. With one of the finest web designers ready to provide you with innovative ideas and endless possibilities, you can present your product or service quite beautifully and impress your customers.
           Our services are user friendly requiring no special programming knowledge and we are dedicated to provide quality support at cheap prices.So what are you waiting for? Get superb designing help and reach out with your own SEO friendly website....
      <br></p></div>
      
      <div style="padding:20px;">
      	<a class="btn btn-info" role="button" href="#">Open to Know More..>></a>
      </div>
  	  
  	  
  </div>
  <div id="virtual" class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
      <div id="imgid3" class="col-lg-4 col-md-5 col-sm-4 col-xs-4">
      	   <img  src="images/virtual.png" class="img-responsive" >
      </div>
      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
      	   <h4>
  	  		&nbsp;&nbsp;&nbsp;&nbsp;Virtual <br>Desigining<br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;& <br>Development<br>
  	  	   </h4> 	  
  	  
      </div>
      <div class="col-lg-11 col-md-11 col-sm-11 col-xs-11">
      	   <p>We provide technical assistance to non-professional computer users and answer questions or resolve computer problems for clients in person, or via telephone or electronically.
           We also provide assistance concerning the use of computer hardware and software, including printing, installation, word processing, electronic mail, and operating systems.We can help u use your PC like a pro.
       <br><br><br><br></p></div>
       
       <div style="padding:20px;">
      	<a class="btn btn-info" role="button" href="#">Open to Know More..>></a>
      </div>
  	  
  	  
  </div>
  <div id="mobile" class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
      <div id="imgid3" class="col-lg-4 col-md-5 col-sm-4 col-xs-4">
      	   <img  src="images/mobile.png" class="img-responsive" >
      </div>
      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
      	   <h4>
  	  		&nbsp;&nbsp;&nbsp;&nbsp;Mobile <br>Desigining<br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;& <br>Development<br>
  	  	   </h4> 	  
  	  
      </div>
      <div class="col-lg-11 col-md-11 col-sm-11 col-xs-11">
      	<p>We help you to build Android apps from scratch or incorporate Java applications into your Android development process. Learn to build where 71% of mobile developers develop for Android in the world.
        Learn everything from installing the Android Developer Tools and developing your first app, to monetizing it and distributing it through Google Play and other app stores.</br><br>
       <br><br></p></div>
     
      <div style="padding:20px;">
      	<a class="btn btn-info" role="button" href="#">Open to Know More..>></a>
      </div>
  	  
  	  
  </div>
  <div id="soft" class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
      <div id="imgid4"  class="col-lg-4 col-md-5 col-sm-4 col-xs-4">
      	   <img  src="images/soft.png" class="img-responsive" >
      </div>
      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
      	   <h4>
  	  		&nbsp;&nbsp;&nbsp;&nbsp;Software<br>Desigining<br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;& <br>Development<br>
  	  	   </h4> 	  
  	  
      </div>
      <div class="col-lg-11 col-md-11 col-sm-11 col-xs-11">
      <p>
      	Want to build custom software for your daily use or want to design a software for use at office? We can help.With our superior software designing platform we can design software ranging from simple to ones that can earn you money.Our help ranges from concept and strategy, to design, implementation and support.
        Our solutions are being used in many projects for some of the world’s leading brands in the financial services, healthcare, travel & hospitality, media sectors.
       <br><br> </p></div>
     
      <div style="padding:20px;">
      	<a class="btn btn-info" role="button" href="#">Open to Know More..>></a>
      </div>
  </div>
</div>


	