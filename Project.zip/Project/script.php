<script type="text/javascript" src="js/jquery.min.js" ></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript">
$('document').ready(function(){
$('#icon img').click(function() {
  var v=$(this).attr('src');
  $('#modalimage').attr('src',v);
});
});


$('document').ready(function(){
    $("#drop").click(function(){
        $("#submenu").slideToggle("slow");
    });
});

$('document').ready(function() {
    $("#bt").click( function() {
         $("#menu").slideToggle("slow");      
    });
});




</script>
