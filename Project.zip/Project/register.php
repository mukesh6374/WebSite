<div class="container">
<!-- Modal -->
<div id="modal" class="modal fade " role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><strong>LOG-IN TO YOUR ACCOUNT</strong></h4>
      </div>
      <div class="modal-body " >
      <form action="<?php echo 'logout.php' ?>" method="post" class="form-horizontal "role="form">
       <div class="form-group ">
             <label class="label-control col-lg-3 col-md-3 col-sm-3 col-xs-3" id="lab" for="user" ><span id="gly" class="glyphicon glyphicon-user"></span></label>
                   <div class=" col-lg-7 col-md-6 col-sm-7 col-xs-9 ">
                      <input type="text" class="form-control " id="user" name="user" placeholder="Enter Your Username" ></input>
                   </div>
              
       </div>
       <div class="form-group ">
             <label class="label-control col-lg-3 col-md-3 col-sm-3 col-xs-3" id="lab" for="email" ><span id="gly" class="glyphicon glyphicon-envelope"></span></label>
                   <div class=" col-lg-7 col-md-6 col-sm-7 col-xs-9 ">
                      <input type="text" class="form-control " id="user" name="user" placeholder="email@gmail.com" ></input>
                   </div>
              
       </div>
       <div class="form-group ">
             <label class="label-control col-lg-3 col-md-3 col-sm-3 col-xs-3" id="lab" for="mbno" ><span id="gly" class="   glyphicon glyphicon-phone"></span></label>
                   <div class=" col-lg-7 col-md-6 col-sm-7 col-xs-9 ">
                      <input type="text" class="form-control " id="mbno" name="mbno" placeholder="Mobile Number" ></input>
                   </div>
              
       </div>
       <div class="form-group ">
             <label class="label-control col-lg-3 col-md-3 col-sm-3 col-xs-3" id="lab" for="password"><span id="gly" class="glyphicon glyphicon-qrcode"></span></label>
                   <div class="col-lg-7 col-md-6 col-sm-7 col-xs-9 ">
                      <input type="password" class="form-control" name="pwd" id="pwd"  placeholder="Your Password is Safe." ></input>
                   </div>
      
       </div>  
       <div class="form-group ">
             <label class="label-control col-lg-3 col-md-3 col-sm-3 col-xs-3" id="lab" for="password"><span id="gly" class="glyphicon glyphicon-calendar"></span></label>
                   <div class="col-lg-7 col-md-6 col-sm-7 col-xs-9 ">
                      <input type="date" class=" form-control datepicker" name="dob" id="dob"  placeholder="Date of birth"  data-date-format="dd/mm/yyyy">
                   </div>
      
       </div> 
       <div class="form-group ">
             <label class="label-control col-lg-12 col-md-12 col-sm-12 col-xs-12">
               
            
                   <div style="padding-left:50%;"class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ">
                   <button id="logbt" type="submit" class="btn">Register</button>
                   
                      
                   </div>
            </label>
      
       </div>   
           
           
    </form>
      </div>
      
    </div>

  </div>
</div>
</div>