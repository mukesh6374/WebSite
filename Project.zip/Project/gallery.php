<div  id="gallery" class="col-lg-12 col-md-12 col-sm-12 col-xs-12 justified">
    <div id="galpanel"class="panel panel-default">
         <div class="panel-heading" ><strong>GALLERY</strong></div>
              <div id="gal" class="panel-body">
                   <?php 
                  	     $var=glob("uploads/*.{jpg,jpeg,png}",GLOB_BRACE);

                         foreach($var as $index)
                            {
                               
                               ?>
                                 <div id="icon" class="col-lg-2 col-md-3 col-sm-5 col-xs-6">
                                 <a href="#myModal" data-toggle="modal" ><img id="galimg" src=" <?php echo $index ?> " class="img-responsive img-circle" ></a>
                                 </div>
                      <?php
                          }

                            ?>
            </div>
    </div>
</div>



