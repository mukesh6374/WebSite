<html lang="en">
<?php include'donnect.php' ?>
<head>
<title>
	Softwarez Solution
</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/bootstrap.min.css" >
<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
<link rel="stylesheet" type="text/css" href="css/style.css" >
<link rel="stylesheet" type="text/css" href="css/bootstrap-datepicker.css">
<?php include'modal.php'; ?>

<?php include'login.php' ?>
<?php include'register.php' ?>


</head>

<body>
  <?php 
      
         if(!isset($_SESSION['user']))
         {
         	
         	$_SESSION['login']=0;

         	
          
         	if(($_SERVER['REQUEST_METHOD']=='POST')&&(isset($_REQUEST['user'])) &&(isset($_REQUEST['pwd'])))
         	{
                 
                 $_SESSION['user']=$_REQUEST['user'];
                 $_SESSION['pwd']=$_REQUEST['pwd'];
                 $_SESSION['login']=1;
         	}
         }

  ?>
	<div id="wrapper">
	     <?php include'header.php' ?>
	     <div class="container col-lg-12 col-md-12 col-sm-12 col-xs-12">
	         <div class="row">
	             <?php include'slider.php' ?>
	             <ul style="font-size:25px; background-color:#A56; margin-bottom:0px;">WHAT WE DO...</ul>
	              <?php include'strip.php'; ?>
	             <?php include'gallery.php' ?>
	             <?php include 'footer.php'; ?>
	             


	         </div>
	        
	     </div>

	     
	</div>
	<?php include'script.php' ?>
	<script type="text/javascript" src="js/bootstrap-datepicker.js"></script>
<script type="text/javascript">
$(document).ready(function()
 {
   $('.datepicker').datepicker();
 });
</script>
</body>

</html>
